function back() {
    OCH5_dismissViewController();
}

function btn() {
	var str = "wzzoch5://test2/test2.html";
    OCH5_presentVCWithUrl(str);
}
