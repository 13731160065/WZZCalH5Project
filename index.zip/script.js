function back() {
    och5_jsContext.popVC();
}

function btn() {
	var str = "wzzoch5://test2/test2.html";
	var nextVC = och5_jsContext.allocWithClass("WZZOCH5VC");
	och5_jsContext.setObjWithKeyPathValueObj("url", str, nextVC);
	och5_jsContext.pushVC(nextVC);
}
