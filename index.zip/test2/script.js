function back() {
    OCH5_dismissViewController();
}

function btn() {
    window.alert("测试, 1.0.1");
}
